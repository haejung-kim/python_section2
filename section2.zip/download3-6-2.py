#  Chrome Driver 이용
import sys
import io

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

import time
# 너무 빨리 진행되어서 time sleep을 줌

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')


chrome_options=Options()
chrome_options.add_argument("--headless")  #CLI 환경

driver = webdriver.Chrome(chrome_options=chrome_options,executable_path='d:/python/chromedriver')

# driver = webdriver.Chrome('d:/python/chromedriver')
#.exe파일 까지 표현안해주어도 됨
# driver.set_window_size(1920,1080)   #화면 사이즈를 조절할수 있음

# driver.implicitly_wait(5)
driver.get('https://google.com')
driver.save_screenshot('d:/python/website3.png')

# driver.implicitly_wait(5)
driver.get('https://www.daum.net')
driver.save_screenshot('d:/python/website4.png')


driver.quit()
print('스크린샷 완료')
