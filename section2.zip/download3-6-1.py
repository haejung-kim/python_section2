# PhantomJS  (CLI 환경으로 제어할수 있어서 편리함 )
import sys
import io

from selenium import webdriver

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')

# browser = webdriver.Chrome('d:/python/chromedriver.exe')

driver = webdriver.PhantomJS('d:/python/phantomjs.exe')
driver.implicitly_wait(5)
# 무조건 5초가 아님, 그전에 Loading 되면 빨리 동작함

driver.get('https://google.com')
driver.save_screenshot('d:/python/website1.png')
# 처음에 C driver에 저장했는데 안됨 ,why? 관리자 권한으로 실행안해서


driver.implicitly_wait(5)
driver.get('https://www.daum.net')
driver.save_screenshot('d:/python/website2.png')


driver.quit()
print('스크린샷 완료')
